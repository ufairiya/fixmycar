<?php
$config['api_key'] = "81ms6dw1qggk5z";
$config['secret_key'] = "fanOfVIy0CgPvZUK";
